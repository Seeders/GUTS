  init() {        
        this.placed = false;
    }