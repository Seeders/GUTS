 init( {level = 1}) {
        this.level = level;
    }